import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/hive_record.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'khalti.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE hives (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          number INTEGER NOT NULL UNIQUE,
          type TEXT NOT NULL,
          strength TEXT NOT NULL
        )
      ''');
    });
    return _db!;
  }

  Future<List<HiveRecord>> getHives() async {
    final rows = await (await database).query('hives', orderBy: 'number ASC');
    return rows.map(HiveRecord.fromMap).toList();
  }

  Future<int> insertHive(HiveRecord hive) async => (await database).insert(
    'hives', hive.toMap(), conflictAlgorithm: ConflictAlgorithm.abort);
}
