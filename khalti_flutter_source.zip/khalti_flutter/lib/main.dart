import 'package:flutter/material.dart';
import 'data/app_database.dart';
import 'models/hive_record.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.instance.database;
  runApp(const KhaltiApp());
}

class KhaltiApp extends StatelessWidget {
  const KhaltiApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'خليتي',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE5A323)), useMaterial3: true),
    home: const DashboardPage(),
  );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List<HiveRecord> hives = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _loadHives();
  }

  Future<void> _loadHives() async {
    final result = await AppDatabase.instance.getHives();
    if (!mounted) return;
    setState(() { hives = result; loading = false; });
  }

  Future<void> _addHive() async {
    final hive = await showDialog<HiveRecord>(context: context, builder: (_) => const AddHiveDialog());
    if (hive == null) return;
    try {
      await AppDatabase.instance.insertHive(hive);
      await _loadHives();
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('رقم الخلية مستخدم من قبل. اختر رقماً آخر.')));
    }
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('خليتي 🐝'), centerTitle: true),
      floatingActionButton: FloatingActionButton.extended(onPressed: _addHive, icon: const Icon(Icons.add), label: const Text('إضافة خلية')),
      body: loading ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(
        onRefresh: _loadHives,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('ملخص المنحل', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('عدد الخلايا المسجلة: ${hives.length}', style: const TextStyle(fontSize: 17)),
            const Text('البيانات محفوظة محلياً على الجهاز.'),
          ]))),
          const SizedBox(height: 12),
          const Text('خلايا المنحل', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (hives.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(20), child: Text('لا توجد خلايا بعد. اضغط «إضافة خلية» للبدء.'))),
          ...hives.map((h) => Card(child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.hive_outlined)),
            title: Text('${h.name} — رقم ${h.number}'),
            subtitle: Text('النوع: ${h.type} • القوة: ${h.strength}'),
          ))),
          const SizedBox(height: 90),
        ]),
      ),
    ),
  );
}

class AddHiveDialog extends StatefulWidget {
  const AddHiveDialog({super.key});
  @override
  State<AddHiveDialog> createState() => _AddHiveDialogState();
}

class _AddHiveDialogState extends State<AddHiveDialog> {
  final name = TextEditingController();
  final number = TextEditingController();
  final type = TextEditingController(text: 'بلدي');
  final strength = TextEditingController(text: 'متوسطة');

  @override
  void dispose() { name.dispose(); number.dispose(); type.dispose(); strength.dispose(); super.dispose(); }

  void save() {
    final n = int.tryParse(number.text.trim());
    if (name.text.trim().isEmpty || n == null || n < 1) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل اسم الخلية ورقماً صحيحاً أكبر من صفر')));
      return;
    }
    Navigator.pop(context, HiveRecord(name: name.text.trim(), number: n, type: type.text.trim(), strength: strength.text.trim()));
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('إضافة خلية جديدة'),
    content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم الخلية')),
      TextField(controller: number, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'رقم الخلية')),
      TextField(controller: type, decoration: const InputDecoration(labelText: 'نوع الخلية')),
      TextField(controller: strength, decoration: const InputDecoration(labelText: 'قوة الطائفة')),
    ])),
    actions: [
      TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
      FilledButton(onPressed: save, child: const Text('حفظ')),
    ],
  );
}
