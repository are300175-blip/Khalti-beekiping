class HiveRecord {
  final int? id;
  final String name;
  final int number;
  final String type;
  final String strength;

  const HiveRecord({this.id, required this.name, required this.number, required this.type, required this.strength});

  Map<String, Object?> toMap() => {'id': id, 'name': name, 'number': number, 'type': type, 'strength': strength};

  factory HiveRecord.fromMap(Map<String, Object?> map) => HiveRecord(
    id: map['id'] as int?,
    name: map['name'] as String,
    number: map['number'] as int,
    type: map['type'] as String,
    strength: map['strength'] as String,
  );
}
